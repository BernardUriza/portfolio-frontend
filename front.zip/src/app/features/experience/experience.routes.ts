import { Routes } from '@angular/router';
import { ExperienceListComponent } from './experience-list/experience-list.component';

export const routes: Routes = [
  { path: '', component: ExperienceListComponent }
];
