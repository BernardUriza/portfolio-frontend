import { Component } from '@angular/core';

@Component({
  selector: 'app-cases',
  standalone: true,
  imports: [],
  templateUrl: './cases.html',
  styleUrl: './cases.scss'
})
export class Cases {

}
